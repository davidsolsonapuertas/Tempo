package com.example.tempo1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class GeneratedPlaylistActivity : AppCompatActivity(), Adapter.CallbackInterface {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_generated_playlist)

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)

        recyclerView.setHasFixedSize(true)

        val layoutManager = LinearLayoutManager(this@GeneratedPlaylistActivity)
        recyclerView.layoutManager = layoutManager

        var myDataset = ArrayList<SongDetails>()

        myDataset.add(SongDetails("Song", "Artist", "Length", R.drawable.musicnote))
        myDataset.add(SongDetails("Song", "Artist", "Length", R.drawable.musicnote))
        myDataset.add(SongDetails("Song", "Artist", "Length", R.drawable.musicnote))
        myDataset.add(SongDetails("Song", "Artist", "Length", R.drawable.musicnote))
        myDataset.add(SongDetails("Song", "Artist", "Length", R.drawable.musicnote))
        myDataset.add(SongDetails("Song", "Artist", "Length", R.drawable.musicnote))
        myDataset.add(SongDetails("Song", "Artist", "Length", R.drawable.musicnote))
        myDataset.add(SongDetails("Song", "Artist", "Length", R.drawable.musicnote))
        myDataset.add(SongDetails("Song", "Artist", "Length", R.drawable.musicnote))


        val adapter = Adapter(myDataset,this)
        recyclerView.adapter = adapter

        val submitButton = findViewById<Button>(R.id.createPlaylistButton)


    }



    override fun onClick(position: Int, songInfo: SongDetails) {
        TODO("Not yet implemented")
    }


}
