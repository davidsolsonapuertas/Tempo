package com.example.tempo1

data class SongDetails(var song: String, var artist : String, var length: String, val cover : Int)
